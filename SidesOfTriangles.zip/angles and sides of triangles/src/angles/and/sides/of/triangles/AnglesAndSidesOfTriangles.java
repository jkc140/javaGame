package angles.and.sides.of.triangles;
/**
 * @author Liam.c
 */
import java.util.Scanner;
public class AnglesAndSidesOfTriangles {

    /**
     * @param args the command line arguments
     */
    /**
     * Lower case variables are side lengths and Upper case variables are the 
     * angles with those side lengths
     */
    double a,b,c;
    double A,B,C;
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
